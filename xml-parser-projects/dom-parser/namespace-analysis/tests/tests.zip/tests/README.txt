A test consists of two XML files, the Input (e.g., "input.xml") and the Report
(e.g., "input-report.xml").

The input can have any base name you feel like, but generally be consistent.

The corresponding report must always be of the form 
	input-base-name + "-report.xml".

The report format is described by "namespaceAnalysisReport.dtd". Your report file 
has to comply with that DTD. There are extra constraints described in the comments.
Your report file must comply with that.